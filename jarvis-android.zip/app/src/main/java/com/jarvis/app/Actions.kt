package com.jarvis.app

import android.content.Context
import android.content.Intent
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.provider.Settings
import org.json.JSONObject

object Actions {
    fun parse(r: String): JSONObject? {
        val s = r.indexOf('{'); val e = r.lastIndexOf('}')
        if (s < 0 || e < s) return null
        return try { JSONObject(r.substring(s, e + 1)).takeIf { it.has("action") } } catch (x: Exception) { null }
    }

    private fun go(c: Context, i: Intent) = c.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))

    fun run(c: Context, a: JSONObject): String = try {
        when (a.getString("action")) {
            "open_app" -> {
                val q = a.getString("app").lowercase(); val pm = c.packageManager
                val li = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
                val m = pm.queryIntentActivities(li, 0).firstOrNull { it.loadLabel(pm).toString().lowercase().contains(q) }
                if (m == null) "uygulama bulunamadı"
                else { go(c, pm.getLaunchIntentForPackage(m.activityInfo.packageName)!!); "açıldı" }
            }
            "flashlight" -> {
                val cm = c.getSystemService(CameraManager::class.java)
                cm.setTorchMode(cm.cameraIdList[0], a.getBoolean("on")); "tamam"
            }
            "volume" -> {
                val am = c.getSystemService(AudioManager::class.java)
                val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
                am.setStreamVolume(AudioManager.STREAM_MUSIC, a.getInt("level") * max / 100, 0); "ses ayarlandı"
            }
            "brightness" -> {
                if (!Settings.System.canWrite(c)) {
                    go(c, Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:${c.packageName}")))
                    "izin gerekli, izin sayfasını açtım"
                } else {
                    Settings.System.putInt(c.contentResolver, Settings.System.SCREEN_BRIGHTNESS_MODE, 0)
                    Settings.System.putInt(c.contentResolver, Settings.System.SCREEN_BRIGHTNESS, a.getInt("level") * 255 / 100)
                    "parlaklık ayarlandı"
                }
            }
            "open_settings" -> {
                go(c, Intent(when (a.optString("page")) {
                    "wifi" -> Settings.ACTION_WIFI_SETTINGS
                    "bluetooth" -> Settings.ACTION_BLUETOOTH_SETTINGS
                    "display" -> Settings.ACTION_DISPLAY_SETTINGS
                    "sound" -> Settings.ACTION_SOUND_SETTINGS
                    else -> Settings.ACTION_SETTINGS
                })); "ayarlar açıldı"
            }
            "read_notifications" ->
                JarvisNotifService.recent.joinToString("\n").ifEmpty { "bildirim yok (bildirim erişimi verilmemiş olabilir)" }
            "open_notification_access" -> { go(c, Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)); "sayfa açıldı" }
            else -> "bilinmeyen eylem"
        }
    } catch (e: Exception) { "hata: ${e.message}" }
}
