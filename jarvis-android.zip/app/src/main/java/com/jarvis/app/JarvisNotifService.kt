package com.jarvis.app

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import java.util.concurrent.CopyOnWriteArrayList

class JarvisNotifService : NotificationListenerService() {
    companion object { val recent = CopyOnWriteArrayList<String>() }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        val e = sbn.notification.extras
        val t = e.getCharSequence("android.title"); val x = e.getCharSequence("android.text")
        if (t == null && x == null) return
        val app = try { packageManager.getApplicationLabel(packageManager.getApplicationInfo(sbn.packageName, 0)) }
                  catch (_: Exception) { sbn.packageName }
        recent.add("$app | $t: $x")
        while (recent.size > 30) recent.removeAt(0)
    }
}
