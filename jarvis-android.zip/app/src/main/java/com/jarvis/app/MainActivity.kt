package com.jarvis.app

import android.content.Intent
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.util.Locale

class MainActivity : ComponentActivity() {
    private var tts: TextToSpeech? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this) {
            if (it == TextToSpeech.SUCCESS) { tts?.language = Locale("tr", "TR"); tts?.setPitch(0.75f); tts?.setSpeechRate(0.95f) }
        }
        val store = Store(this)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                Surface { App(store) { tts?.speak(it, TextToSpeech.QUEUE_FLUSH, null, "j") } }
            }
        }
    }
    override fun onDestroy() { tts?.shutdown(); super.onDestroy() }
}

@Composable
fun App(store: Store, speak: (String) -> Unit) {
    var tab by remember { mutableIntStateOf(0) }
    Scaffold(bottomBar = {
        NavigationBar {
            NavigationBarItem(tab == 0, { tab = 0 }, { Text("💬") }, label = { Text("Jarvis") })
            NavigationBarItem(tab == 1, { tab = 1 }, { Text("⚙️") }, label = { Text("Ayarlar") })
        }
    }) { p -> Box(Modifier.padding(p)) { if (tab == 0) Chat(store, speak) else SettingsScreen(store) } }
}

@Composable
fun Chat(store: Store, speak: (String) -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val msgs = remember { mutableStateListOf<Pair<String, String>>() }
    val hist = remember { mutableListOf<JSONObject>() }
    var input by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }

    fun send(t: String) {
        if (t.isBlank() || busy) return
        input = ""; msgs.add("Sen" to t); busy = true
        scope.launch {
            val r = try { Brain.ask(ctx, store, hist, t) } catch (e: Exception) { "Hata: ${e.message}" }
            msgs.add("Jarvis" to r); speak(r); busy = false
        }
    }
    val mic = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        r.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()?.let { send(it) }
    }
    Column(Modifier.fillMaxSize().padding(8.dp)) {
        LazyColumn(Modifier.weight(1f)) { items(msgs) { (who, t) -> Text("$who: $t", Modifier.padding(4.dp)) } }
        if (busy) Text("Jarvis düşünüyor…")
        Row {
            OutlinedTextField(input, { input = it }, Modifier.weight(1f))
            Button({
                mic.launch(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                    .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "tr-TR"))
            }) { Text("🎤") }
            Button({ send(input) }) { Text("➤") }
        }
    }
}

@Composable
fun SettingsScreen(st: Store) {
    val scope = rememberCoroutineScope()
    var id by remember { mutableStateOf(st.activeId()) }
    var key by remember { mutableStateOf("") }
    var base by remember { mutableStateOf("") }
    var model by remember { mutableStateOf("") }
    var status by remember { mutableStateOf("") }
    var models by remember { mutableStateOf(listOf<String>()) }

    fun load(i: String) { id = i; val p = st.get(i); key = p.key; base = p.base; model = p.model; models = emptyList(); status = "" }
    LaunchedEffect(Unit) { load(id) }

    Column(Modifier.padding(12.dp).verticalScroll(rememberScrollState())) {
        Text("Aktif sağlayıcı: ${st.activeId()}")
        Row(Modifier.horizontalScroll(rememberScrollState())) {
            Store.names.forEach { (i, n) -> FilterChip(id == i, { load(i) }, { Text(n) }, Modifier.padding(end = 6.dp)) }
        }
        OutlinedTextField(key, { key = it }, label = { Text("API Key") },
            visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth())
        OutlinedTextField(base, { base = it }, label = { Text("Base URL") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(model, { model = it }, label = { Text("Model") }, modifier = Modifier.fillMaxWidth())
        Row {
            Button({
                status = "Test ediliyor…"
                scope.launch {
                    status = try { val m = withContext(Dispatchers.IO) { Llm.models(base, key) }; "✅ Çalışıyor (${m.size} model)" }
                            catch (e: Exception) { "❌ ${e.message}" }
                }
            }) { Text("Test") }
            Spacer(Modifier.width(8.dp))
            Button({
                scope.launch {
                    try { models = withContext(Dispatchers.IO) { Llm.models(base, key) }; status = "${models.size} model geldi, birine dokun" }
                    catch (e: Exception) { status = "❌ ${e.message}" }
                }
            }) { Text("Modelleri getir") }
        }
        Button({ st.save(Prov(id, base, key, model)); st.setActive(id); status = "Kaydedildi, aktif: $id" }) { Text("Kaydet ve aktif yap") }
        Text(status)
        models.forEach { Text(it, Modifier.fillMaxWidth().clickable { model = it }.padding(6.dp)) }
    }
}
