package com.jarvis.app

import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

object Llm {
    private val c = OkHttpClient.Builder().readTimeout(60, TimeUnit.SECONDS).build()

    fun models(base: String, key: String): List<String> {
        val r = Request.Builder().url("${base.trimEnd('/')}/models")
            .header("Authorization", "Bearer $key").build()
        c.newCall(r).execute().use {
            val body = it.body?.string() ?: ""
            if (!it.isSuccessful) error("HTTP ${it.code}: ${body.take(200)}")
            val a = JSONObject(body).getJSONArray("data")
            return (0 until a.length()).map { i -> a.getJSONObject(i).getString("id") }.sorted()
        }
    }

    fun chat(base: String, key: String, model: String, hist: List<JSONObject>, system: String): String {
        val msgs = JSONArray().put(JSONObject().put("role", "system").put("content", system))
        hist.forEach { msgs.put(it) }
        val body = JSONObject().put("model", model.removePrefix("models/")).put("messages", msgs)
        val r = Request.Builder().url("${base.trimEnd('/')}/chat/completions")
            .header("Authorization", "Bearer $key")
            .post(body.toString().toRequestBody("application/json".toMediaType())).build()
        c.newCall(r).execute().use {
            val s = it.body?.string() ?: ""
            if (!it.isSuccessful) error("HTTP ${it.code}: ${s.take(200)}")
            return JSONObject(s).getJSONArray("choices").getJSONObject(0)
                .getJSONObject("message").getString("content").trim()
        }
    }
}
