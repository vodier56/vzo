package com.jarvis.app

import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

data class Prov(val id: String, val base: String, val key: String, val model: String)

class Store(ctx: Context) {
    private val sp = EncryptedSharedPreferences.create(
        ctx, "jarvis",
        MasterKey.Builder(ctx).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build(),
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )
    companion object {
        // Base URL'ler ayarlardan değiştirilebilir
        val names = listOf("gemini" to "Gemini", "groq" to "Groq", "openrouter" to "OpenRouter",
            "fastrouter" to "FastRouter", "custom" to "Özel")
        val bases = mapOf(
            "gemini" to "https://generativelanguage.googleapis.com/v1beta/openai",
            "groq" to "https://api.groq.com/openai/v1",
            "openrouter" to "https://openrouter.ai/api/v1",
            "fastrouter" to "https://go.fastrouter.ai/api/v1",
            "custom" to ""
        )
    }
    fun get(id: String) = Prov(id, sp.getString("b_$id", bases[id] ?: "")!!,
        sp.getString("k_$id", "")!!, sp.getString("m_$id", "")!!)
    fun save(p: Prov) = sp.edit().putString("b_${p.id}", p.base).putString("k_${p.id}", p.key)
        .putString("m_${p.id}", p.model).apply()
    fun activeId() = sp.getString("active", "gemini")!!
    fun setActive(id: String) = sp.edit().putString("active", id).apply()
    fun active() = get(activeId())
}
