package com.jarvis.app

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject

object Brain {
    const val SYS = """Sen Jarvis'sin: kısa, zeki, kibar bir sesli asistan. Türkçe konuş, cevapların kısa olsun.
Telefonda işlem gerekirse SADECE tek bir JSON ile cevap ver, başka metin yazma:
{"action":"open_app","app":"WhatsApp"}
{"action":"flashlight","on":true}
{"action":"volume","level":0-100}
{"action":"brightness","level":0-100}
{"action":"open_settings","page":"wifi|bluetooth|display|sound|main"}
{"action":"read_notifications"}
{"action":"open_notification_access"}
Normal sohbette düz metin yaz."""

    private fun msg(role: String, text: String) = JSONObject().put("role", role).put("content", text)

    suspend fun ask(ctx: Context, st: Store, hist: MutableList<JSONObject>, text: String): String =
        withContext(Dispatchers.IO) {
            val p = st.active()
            if (p.key.isBlank() || p.model.isBlank()) return@withContext "Ayarlardan anahtar ve model seç."
            hist.add(msg("user", text))
            var reply = Llm.chat(p.base, p.key, p.model, hist.takeLast(20), SYS)
            val act = Actions.parse(reply)
            if (act != null) {
                hist.add(msg("assistant", reply))
                val res = Actions.run(ctx, act)
                hist.add(msg("user", "Araç sonucu: $res\nBunu kullanıcıya kısaca Türkçe söyle. JSON kullanma."))
                reply = Llm.chat(p.base, p.key, p.model, hist.takeLast(20), SYS)
            }
            hist.add(msg("assistant", reply))
            reply
        }
}
